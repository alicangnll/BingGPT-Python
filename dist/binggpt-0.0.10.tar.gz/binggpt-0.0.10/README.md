# BingGPT - Bing API on Python
You can use BingGPT API on Python!
# Requirements
<ul>
  <li>Python 3.8+</li>
</ul>
<h1>Installation</h1>
<ul>
  <li>pip install -r requirements.txt</li>
  <li>pip install dist/binggpt-0.0.10-py3-none-any.whl</li>
</ul>
<h1>Example</h1>
<br>
<a href="example.py">Example Code</a>
