# BingGPT - Bing API on Python
You can use BingGPT API on Python!
# Requirements
<ul>
<li>Python 3.8+</li>
</ul>
<h1> Installation</h1>
<ul>
<li>pip install -r requirements.txt</li>
</ul>
