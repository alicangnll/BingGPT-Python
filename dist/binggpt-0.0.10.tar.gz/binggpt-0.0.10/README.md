# BingGPT - Bing AI API on Python
You can use BingGPT AI API on Python!
# Requirements
<ul>
  <li>Python 3.8+</li>
</ul>
<h1>Installation</h1>
<ul>
  <li>pip install -r requirements.txt</li>
  <li>pip install dist/binggpt-0.0.10-py3-none-any.whl</li>
</ul>
<h1>Pictures</h1>
<img src="pic/pic1.png" />
<img src="pic/pic2.png" />
<h1>Example</h1>
<a href="examples/example.py">Example Code</a>
<br><a href="examples/example2.py">Example Code 2</a>
